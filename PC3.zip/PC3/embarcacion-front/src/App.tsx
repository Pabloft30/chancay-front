import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Embarcacion } from './types';
import EmbarcacionForm from './components/EmbarcacionForm';
import EmbarcacionTable from './components/EmbarcacionTable';

const App: React.FC = () => {
  const [embarcaciones, setEmbarcaciones] = useState<Embarcacion[]>([]);
  const [embarcacionEdit, setEmbarcacionEdit] = useState<Embarcacion | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    obtenerEmbarcaciones();
  }, []);

  const obtenerEmbarcaciones = async () => {
    try {
      const respuesta = await axios.get('/api/embarcaciones');
      setEmbarcaciones(respuesta.data);
      setError(null);
    } catch (error) {
      console.error('Error al obtener embarcaciones:', error);
      setError('Error al cargar las embarcaciones');
    }
  };

  const validarEmbarcacion = (embarcacion: Omit<Embarcacion, 'id'>): boolean => {
    if (!embarcacion.nombre || embarcacion.nombre.trim() === '') {
      setError('El nombre es requerido');
      return false;
    }
    if (embarcacion.capacidad <= 0) {
      setError('La capacidad debe ser mayor a 0');
      return false;
    }
    if (!embarcacion.descripcion || embarcacion.descripcion.trim() === '') {
      setError('La descripción es requerida');
      return false;
    }
    if (!embarcacion.fechaProgramada || embarcacion.fechaProgramada.trim() === '') {
      setError('La fecha programada es requerida');
      return false;
    }
    return true;
  };

  const manejarCrear = async (embarcacion: Omit<Embarcacion, 'id'>) => {
    try {
      setError(null);
      if (!validarEmbarcacion(embarcacion)) {
        return;
      }

      const embarcacionFormateada = {
        ...embarcacion,
        capacidad: Number(embarcacion.capacidad),
        fechaProgramada: new Date(embarcacion.fechaProgramada).toISOString().split('T')[0]
      };

      await axios.post('/api/embarcaciones', embarcacionFormateada);
      await obtenerEmbarcaciones();
    } catch (error: any) {
      console.error('Error al crear embarcación:', error);
      setError(error.response?.data?.message || 'Error al crear la embarcación');
    }
  };

  const manejarActualizar = async (embarcacion: Omit<Embarcacion, 'id'>) => {
    if (!embarcacionEdit) return;
    try {
      setError(null);
      if (!validarEmbarcacion(embarcacion)) {
        return;
      }

      const embarcacionFormateada = {
        ...embarcacion,
        capacidad: Number(embarcacion.capacidad),
        fechaProgramada: new Date(embarcacion.fechaProgramada).toISOString().split('T')[0]
      };

      await axios.put(`/api/embarcaciones/${embarcacionEdit.id}`, embarcacionFormateada);
      await obtenerEmbarcaciones();
      setEmbarcacionEdit(null);
    } catch (error: any) {
      console.error('Error al actualizar embarcación:', error);
      setError(error.response?.data?.message || 'Error al actualizar la embarcación');
    }
  };

  const manejarEliminar = async (id: number) => {
    try {
      setError(null);
      await axios.delete(`/api/embarcaciones/${id}`);
      await obtenerEmbarcaciones();
    } catch (error: any) {
      console.error('Error al eliminar embarcación:', error);
      setError(error.response?.data?.message || 'Error al eliminar la embarcación');
    }
  };

  const iniciarEdicion = (embarcacion: Embarcacion) => {
    setEmbarcacionEdit(embarcacion);
    setError(null);
  };

  const cancelarEdicion = () => {
    setEmbarcacionEdit(null);
    setError(null);
  };

  return (
    <div className="container-embarcaciones">
      <h1>Gestión de Embarcaciones</h1>
      
      {error && (
        <div style={{ color: 'red', marginBottom: '1rem' }}>
          {error}
        </div>
      )}
      
      <EmbarcacionForm
        onSubmit={embarcacionEdit ? manejarActualizar : manejarCrear}
        initialData={embarcacionEdit || undefined}
        onCancel={embarcacionEdit ? cancelarEdicion : undefined}
      />
      <EmbarcacionTable
        embarcaciones={embarcaciones}
        onEdit={iniciarEdicion}
        onDelete={manejarEliminar}
      />
    </div>
  );
};

export default App;