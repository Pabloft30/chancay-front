export interface Embarcacion {
    id: number;
    nombre: string;
    capacidad: number;
    descripcion: string;
    fechaProgramada: string;
  }